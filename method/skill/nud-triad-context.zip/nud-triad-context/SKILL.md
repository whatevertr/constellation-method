---
name: nud-triad-context
description: >-
  Use SEMPRE que o usuário quiser criar, montar ou preencher um "como trabalhar
  comigo", um "perfil de trabalho", documentos de contexto para colaboração
  humano-IA, ou a "Tríade de Contexto" (porta + manual + função). Acione
  também quando pedir para "montar meu contexto para IA", "ensinar a IA a
  trabalhar do meu jeito", "criar meu manual de uso", "perfil cognitivo de
  trabalho", ou quando trouxer um novo colaborador/instância e quiser gerar os
  documentos que orientam a relação de trabalho. A skill conduz uma
  entrevista curta de múltipla escolha (cerca de uma dúzia de perguntas curtas,
  ou um único .md para preencher em lote) e entrega os cinco arquivos da Tríade.
  NÃO use para diagnóstico psicológico, teste de personalidade recreativo
  (MBTI/eneagrama) nem para avaliar terceiros sem a presença da pessoa.
license: CC-BY-4.0
metadata:
  author: Thainá Ramos (Nud by Whatevertr)
  version: 1.1.0
---

# Tríade de Contexto — gerador de "como trabalhar comigo"

Esta skill produz a **Tríade** — 3 peças, entregues em **5 arquivos .md** — que ensinam qualquer instância de IA a colaborar com uma pessoa específica, com base **exclusivamente** em construtos da psicologia cognitiva validados por método científico:

1. **`comece_aqui`** — A PORTA. Onde a instância entra: objetivo do trabalho e para onde ir.
2. **`como_trabalhar_comigo`** — O MANUAL. Como a cabeça da pessoa funciona (7 dimensões validadas).
3. **A FUNÇÃO** — três **personas** que a pessoa pode usar: `worker` (executar), `thinker` (pensar), `manager` (conduzir). A skill **gera as três** como opções (não se pergunta qual papel — geram-se todas); **a pessoa escolhe qual usar** em cada tarefa (a instância que roda uma tarefa é UMA delas, não as três ao mesmo tempo). Os três arquivos têm o mesmo layout; muda só o bloco do papel.

## Regra suprema
**Extremamente proibido inserir no perfil qualquer coisa não validada cientificamente.** As sete dimensões, os cenários e as frases prontas são o único material permitido para o MANUAL e a FUNÇÃO. Você **não** cria dimensões, **não** improvisa frases de perfil, **não** usa tipologias populares sem validade preditiva (MBTI, eneagrama, estilos de aprendizagem/VARK). Base científica em `referencias.md`.

## O usuário não conhece a skill
A pessoa **não sabe** o que está escrito aqui dentro. **Fale em linguagem plana**, como conversa normal. Nunca narre decisões internas em jargão ("Q2×Q3", "Object/Spatial", "leitura conjunta") nem fale como se ela conhecesse o método — aplique a lógica **em silêncio**. Detalhes em `regras/regras_de_preenchimento.md`.

## Como preencher (motor anti-interpretação)
O ponto onde um modelo mais erra é interpretar. Por isso o perfil é preenchido **só por múltipla escolha**: você faz uma pergunta-cenário, recebe UMA letra (A/B/C/D) e **cola a frase EXATA** correspondente — sem parafrasear. Mecanismo em **`regras/perguntas_e_frases.md`**.

- **Popup padrão + "outros" flexível:** apresente TODA pergunta no popup de múltipla escolha (as pessoas gostam), uma por vez. Sobre o "outros" (texto livre) que o Claude às vezes força: se puder exigir uma letra junto, ótimo; senão, **aproxime a resposta à letra mais próxima** ou faça outra pergunta curta para aproximar. Não trave nem peça confirmação.
- **Perguntas imutáveis:** as 7 perguntas e suas opções são FIXAS. Não reescreva, não reordene, não invente. Alternativa só se a pessoa realmente não conseguir responder.

## Passo a passo (ordem clara — não se confunda)
1. **Leia** `regras/regras_de_preenchimento.md` e `regras/perguntas_e_frases.md` antes de começar.
2. **Abra com o roteiro fixo** (diga assim, sem inventar): "Vou te fazer ~uma dúzia de perguntas curtas de múltipla escolha para montar 5 documentos que ensinam qualquer IA a trabalhar do seu jeito. Não há resposta certa; escolha o que mais parece você."
3. **Conduza a entrevista, uma pergunta por vez, nesta ordem** (com "resposta → arquivo"):
   - **Q0a — nome da PESSOA** + **Q0b — como referir.** ⚠️ O nome da pessoa é diferente do **apelido da instância** (passo do QF). Não confunda.
   - **Q1 → Q7 (as 7 dimensões)** → alimentam SÓ o `como_trabalhar_comigo`.
   - **Perguntas do projeto** (objetivo prático, fundamentação, objetivo abstrato) → alimentam SÓ o `comece_aqui`. **Não pule.**
   - **QF-Tom + QF-Evitar** (múltipla escolha) → o tom dos três papéis.
   - **Apelido da instância (opcional)** → nome da IA. **Se a pessoa não quiser, fica sem apelido** (use "instância").
   - **Nunca pergunte "qual é a função".**
4. **Preencha os arquivos** de `modelos/` colando as frases exatas:
   - `como_trabalhar_comigo.md` ← frases de REGRA (positivas) + NÃO-FUNCIONA (negativas) + 6 Regras Universais.
   - `comece_aqui.md` ← respostas do projeto + versionamento + memória (`_memoria`).
   - `worker.md` / `thinker.md` / `manager.md` (espelhos) ← Worker e Thinker **derivados do manual** (positivo + negativo); Manager **fixo do método** + negativo; cada um com seu piso de papel. Base (tom + piso) idêntica nos três.
   - Cabeçalho de todos: `nome_do_arquivo — versão — DD/MM/AAAA` (versão no cabeçalho, não no nome).
   - Rodapé de todos: *"Gerado com a Tríade de Contexto — método de Thainá Ramos (Nud by Whatevertr) · https://github.com/whatevertr · Licenciado sob CC-BY-4.0."*
   - Nomes canônicos, sem nome de pessoa, sem versão no nome.
5. **Nunca infira gênero pelo nome** — use Q0b; na dúvida, só o nome.
6. **Entregue tudo numa resposta só:** os 5 arquivos **+ a frase de entrega** (`regras/frase_de_entrega.md`) juntos, **sem esperar aprovação** (esperar cria ruído). Feche com um convite leve: "se algo não te representar, me diz que eu ajusto". A pessoa pode **editar livremente** depois; você ajuda sem avisar nada sobre "regras".

## O que fica fixo (não se pergunta)
- O **piso epistêmico** (taça 🍷, colunas observação/inferência/desconhecido, jogo da moeda, conferência de piso) já vem nos templates `modelos/worker.md`, `thinker.md`, `manager.md` — base idêntica + piso específico de cada papel.
- As **6 Regras Universais** já vêm no MANUAL. São o piso de boa prática, com base científica — não preferência da pessoa.

## Estrutura do pacote
```
nud-triad-context/
├── SKILL.md                       (este arquivo)
├── referencias.md                 (base científica — o compromisso de rigor)
├── LICENSE
├── modelos/
│   ├── comece_aqui.md             (PORTA)
│   ├── como_trabalhar_comigo.md   (MANUAL)
│   ├── worker.md                  (FUNÇÃO — papel Worker)
│   ├── thinker.md                 (FUNÇÃO — papel Thinker)
│   └── manager.md                 (FUNÇÃO — papel Manager)
└── regras/
    ├── perguntas_e_frases.md      (motor: 7 cenários → frases prontas + QF + porta)
    ├── regras_de_preenchimento.md (roteiro da entrevista + avisos)
    └── frase_de_entrega.md        (mensagem final + assinatura)
```

---
© 2026 Thainá Ramos (Nud by Whatevertr) · https://github.com/whatevertr · Licenciado sob [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) — uso livre mediante atribuição.
