# Referências — base científica da Tríade de Contexto
*Toda dimensão do MANUAL e toda Regra Universal se apoia em literatura peer-reviewed. Esta lista é o compromisso de rigor da skill: nada entra no perfil sem sustentação aqui. Construtos populares sem validade preditiva (MBTI, eneagrama, estilos de aprendizagem/VARK) foram deliberadamente excluídos.*

> ⚠️ **Disclaimer (anti-overclaiming).** As dimensões ancoram em construtos validados; os itens de elicitação (as perguntas-cenário) são adaptações de item único criadas pela autora, sem validação psicométrica própria — a validação dos itens é trabalho futuro.

## Como cada dimensão se ancora
| Dimensão do MANUAL | Construto | Instrumento | Referência-chave |
|---|---|---|---|
| 1. Motivação para pensar | Need for Cognition | NFC-6 | Cacioppo & Petty (1982); Lins de Holanda Coelho, Hanel & Wolf (2020) |
| 2. Fechamento/estrutura | Need for Cognitive Closure | NFCS-15 | Webster & Kruglanski (1994); Roets & Van Hiel (2011) |
| 3. Cautela ao fechar | Falta de premeditação (UPPS-P) + Fear of Invalidity | UPPS-P; PFI | Whiteside & Lynam (2001); Thompson et al. (2001) |
| 4. Amplitude de busca | Tendência maximizadora (alternative search / high standards) | Maximization Scale short-form | Nenkov et al. (2008); Diab, Gillespie & Highhouse (2008) |
| 5. Analítico ⟷ holístico | Analytic–Holistic thinking | Analysis-Holism Scale | Choi, Koo & Choi (2007); Nisbett et al. (2001) |
| 6. Concreto ⟷ abstrato | Nível de identificação da ação (construal) | Behavior Identification Form | Vallacher & Wegner (1989); Trope & Liberman (2010) |
| 7. Representação verbal ⟷ visual | Modelo Object-Spatial-Verbal | OSIVQ | Blazhenkova & Kozhevnikov (2009) |
| (regra universal) Vividez episódica | Memória autobiográfica | SAM (subescala episódica) | Palombo et al. (2013, 2015) |

## Regras universais — ancoragem
- Estrutura/sinalização e concisão: Sweller, van Merriënboer & Paas (1998); Sweller, Ayres & Kalyuga (2011).
- Fatiar carga / memória de trabalho: Conway et al. (2005).
- Reduzir andaimes por expertise (expertise reversal): Kalyuga (2007).
- Registro escrito de decisões (não confiar na recordação): Palombo et al. (2013).
- Rejeição da meshing hypothesis / estilos de aprendizagem: Pashler, McDaniel, Rohrer & Bjork (2008); (base de corte de vários construtos).

## Cortes fundamentados (por que NÃO entraram)
- **Estilos de aprendizagem / Felder ILS / Riding CSA / VVQ:** família desacreditada e/ou psicometria insuficiente — Pashler et al. (2008); Peterson, Deary & Austin (2003).
- **Field-dependence (Witkin):** mede aptidão, não preferência — Messick (1984); Sternberg & Grigorenko (1997); Kozhevnikov (2007).
- **MFFT (Kagan):** mede competência, não tempo conceitual — Block, Block & Harrington (1974).
- **Fator "decision difficulty" da maximização:** artefato de distress — Diab, Gillespie & Highhouse (2008).
- **Budner (tolerância à ambiguidade):** confiabilidade inaceitável (α≈.47).
- **Modos lógicos (dedutivo/indutivo/abdutivo) e estágios de Piaget:** habilidade (Gf) e desenvolvimento, não estilo.

---

## Lista completa (APA)

Blazhenkova, O., & Kozhevnikov, M. (2009). The new object-spatial-verbal cognitive style model: Theory and measurement. *Applied Cognitive Psychology, 23*(5), 638–663.

Block, J., Block, J. H., & Harrington, D. M. (1974). Some misgivings about the Matching Familiar Figures Test as a measure of reflection–impulsivity. *Developmental Psychology, 10*(5), 611–632.

Cacioppo, J. T., & Petty, R. E. (1982). The need for cognition. *Journal of Personality and Social Psychology, 42*(1), 116–131.

Cacioppo, J. T., Petty, R. E., Feinstein, J. A., & Jarvis, W. B. G. (1996). Dispositional differences in cognitive motivation: The life and times of individuals varying in need for cognition. *Psychological Bulletin, 119*(2), 197–253.

Cheek, N. N., & Schwartz, B. (2016). On the meaning and measurement of maximization. *Judgment and Decision Making, 11*(2), 126–146.

Choi, I., Koo, M., & Choi, J. A. (2007). Individual differences in analytic versus holistic thinking. *Personality and Social Psychology Bulletin, 33*(5), 691–705.

Conway, A. R. A., Kane, M. J., Bunting, M. F., Hambrick, D. Z., Wilhelm, O., & Engle, R. W. (2005). Working memory span tasks: A methodological review and user's guide. *Psychonomic Bulletin & Review, 12*(5), 769–786.

Diab, D. L., Gillespie, M. A., & Highhouse, S. (2008). Are maximizers really unhappy? The measurement of maximizing tendency. *Judgment and Decision Making, 3*(5), 364–370.

Kalyuga, S. (2007). Expertise reversal effect and its implications for learner-tailored instruction. *Educational Psychology Review, 19*(4), 509–539.

Kozhevnikov, M. (2007). Cognitive styles in the context of modern psychology: Toward an integrated framework of cognitive style. *Psychological Bulletin, 133*(3), 464–481.

Kozhevnikov, M., Kosslyn, S., & Shephard, J. (2005). Spatial versus object visualizers: A new characterization of visual cognitive style. *Memory & Cognition, 33*(4), 710–726.

Lins de Holanda Coelho, G., Hanel, P. H. P., & Wolf, L. J. (2020). The very efficient assessment of need for cognition: Developing a six-item version. *Assessment, 27*(8), 1870–1885.

Messick, S. (1984). The nature of cognitive styles: Problems and promise in educational practice. *Educational Psychologist, 19*(2), 59–74.

Nenkov, G. Y., Morrin, M., Ward, A., Schwartz, B., & Hulland, J. (2008). A short form of the Maximization Scale: Factor structure, reliability, and validity studies. *Judgment and Decision Making, 3*(5), 371–388.

Neuberg, S. L., Judice, T. N., & West, S. G. (1997). What the Need for Closure Scale measures and what it does not. *Journal of Personality and Social Psychology, 72*(6), 1396–1412.

Nisbett, R. E., Peng, K., Choi, I., & Norenzayan, A. (2001). Culture and systems of thought: Holistic versus analytic cognition. *Psychological Review, 108*(2), 291–310.

Palombo, D. J., Sheldon, S., & Levine, B. (2015). Severely deficient autobiographical memory (SDAM) in healthy adults. *Neuropsychologia, 72*, 105–118.

Palombo, D. J., Williams, L. J., Abdi, H., & Levine, B. (2013). The Survey of Autobiographical Memory (SAM): A novel measure of trait mnemonics in everyday life. *Cortex, 49*(6), 1526–1540.

Pashler, H., McDaniel, M., Rohrer, D., & Bjork, R. (2008). Learning styles: Concepts and evidence. *Psychological Science in the Public Interest, 9*(3), 105–119.

Peterson, E. R., Deary, I. J., & Austin, E. J. (2003). The reliability of Riding's Cognitive Style Analysis test. *Personality and Individual Differences, 34*(5), 881–891.

Ratcliff, R., & McKoon, G. (2008). The diffusion decision model: Theory and data for two-choice decision tasks. *Neural Computation, 20*(4), 873–922.

Rietzschel, E. F., De Dreu, C. K. W., & Nijstad, B. A. (2007). Personal need for structure and creative performance: The moderating influence of fear of invalidity. *Personality and Social Psychology Bulletin, 33*(6), 855–866.

Roets, A., & Van Hiel, A. (2007). Separating ability from need: Clarifying the dimensional structure of the Need for Closure Scale. *Personality and Social Psychology Bulletin, 33*(2), 266–280.

Roets, A., & Van Hiel, A. (2011). Item selection and validation of a brief 15-item version of the Need for Closure Scale. *Personality and Individual Differences, 50*(1), 90–94.

Sternberg, R. J., & Grigorenko, E. L. (1997). Are cognitive styles still in style? *American Psychologist, 52*(7), 700–712.

Sweller, J., Ayres, P., & Kalyuga, S. (2011). *Cognitive load theory.* Springer.

Sweller, J., van Merriënboer, J. J. G., & Paas, F. (1998). Cognitive architecture and instructional design. *Educational Psychology Review, 10*(3), 251–296.

Thompson, M. M., Naccarato, M. E., Parker, K. C. H., & Neuberg, S. L. (2001). The Personal Need for Structure and Personal Fear of Invalidity measures: Historical perspectives, current applications, and future directions. In G. B. Moskowitz (Ed.), *Cognitive social psychology* (pp. 19–39). Erlbaum.

Trope, Y., & Liberman, N. (2010). Construal-level theory of psychological distance. *Psychological Review, 117*(2), 440–463.

Vallacher, R. R., & Wegner, D. M. (1989). Levels of personal agency: Individual variation in action identification. *Journal of Personality and Social Psychology, 57*(4), 660–671.

Webster, D. M., & Kruglanski, A. W. (1994). Individual differences in need for cognitive closure. *Journal of Personality and Social Psychology, 67*(6), 1049–1062.

Whiteside, S. P., & Lynam, D. R. (2001). The Five Factor Model and impulsivity: Using a structural model of personality to understand impulsivity. *Personality and Individual Differences, 30*(4), 669–689.

Witkin, H. A., Moore, C. A., Goodenough, D. R., & Cox, P. W. (1977). Field-dependent and field-independent cognitive styles and their educational implications. *Review of Educational Research, 47*(1), 1–64.

---
© 2026 Thainá Ramos (Nud by Whatevertr) · https://github.com/whatevertr · Licenciado sob [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) — uso livre mediante atribuição.
